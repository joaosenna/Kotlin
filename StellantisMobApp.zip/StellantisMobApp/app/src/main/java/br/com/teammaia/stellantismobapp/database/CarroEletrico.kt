package br.com.teammaia.stellantismobapp.database

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "carroEletrico")
data class CarroEletrico(@PrimaryKey(autoGenerate = true) var id: Int = 0,
                         @NonNull @ColumnInfo(name = "modelo") val modelo: String,
                         @NonNull @ColumnInfo(name = "percentualBateria") val percentualBateria: String,
                         @NonNull @ColumnInfo(name = "tempoCarregamento")val tempoCarregamento: String,
                         @NonNull @ColumnInfo(name = "autonomiaCargaAtual")val autonomiaCargaAtual: String,
                         @NonNull @ColumnInfo(name = "autonomiaCargaTotal")val autonomiaCargaTotal: String,
                         @NonNull @ColumnInfo(name = "vidaUtilBateria")val vidaUtilBateria: String)