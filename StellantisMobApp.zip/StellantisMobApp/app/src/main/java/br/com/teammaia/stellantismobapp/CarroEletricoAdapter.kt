package br.com.teammaia.stellantismobapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import br.com.teammaia.stellantismobapp.database.CarroEletrico

class CarroEletricoAdapter (private val dataSet: List<CarroEletrico>): RecyclerView.Adapter<CarroEletricoAdapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val textViewModelo: TextView
        val textViewPercentualBateria: TextView
        val textViewTempoCarregamento: TextView
        val textViewAutonomiaCargaAtual: TextView
        val textViewAutonomiaCargaTotal: TextView

        init {
            textViewModelo = view.findViewById(R.id. textViewModelo)
            textViewPercentualBateria = view.findViewById(R.id.textViewPercentualBateria)
            textViewTempoCarregamento = view.findViewById(R.id.textViewTempoCarregamento)
            textViewAutonomiaCargaAtual = view.findViewById(R.id.textViewAutonomiaCargaAtual)
            textViewAutonomiaCargaTotal = view.findViewById(R.id.textViewAutonomiaCargaTotal)

        }
    }

    //Define o layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recyclerview_carroEletrico, parent, false)

        return ViewHolder(view)
    }

    //De/Para Objeto para o layout
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val carroEletrico = dataSet[position]
        holder.textViewModelo.text = carroEletrico.modelo
        holder.textViewPercentualBateria.text = carroEletrico.percentualBateria
        holder.textViewTempoCarregamento.text = carroEletrico.tempoCarregamento
        holder.textViewAutonomiaCargaAtual.text = carroEletrico.autonomiaCargaAtual
        holder. textViewAutonomiaCargaTotal.text = carroEletrico.autonomiaCargaTotal

        holder.itemView.setOnClickListener {
            val bundle = bundleOf("carroEletrico_id" to carroEletrico.id)
            it.findNavController().navigate(R.id.action_carroEletricoFragment_to_formCarroEletricoFragment, bundle)
        }
    }

    //Retorna o tamanho da lista
    override fun getItemCount(): Int {
        return dataSet.size
    }
}
