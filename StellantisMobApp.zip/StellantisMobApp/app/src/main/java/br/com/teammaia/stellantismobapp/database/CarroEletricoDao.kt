package br.com.teammaia.stellantismobapp.database

import androidx.room.*

@Dao

interface CarroEletricoDao {

    @Query("SELECT * FROM carroEletrico ORDER BY modelo ASC")
    fun getAll(): List<CarroEletrico>;

    @Insert
    fun insert(vararg carroEletrico: CarroEletrico)

    @Query("SELECT * FROM carroEletrico WHERE id = :id")
    fun getById(id:Int): CarroEletrico

    @Delete
    fun delete (carroEletrico: CarroEletrico)

    @Update
    fun update (carroEletrico: CarroEletrico)
}
}