package br.com.deyvidfernandes.feedbackwebservice.network

data class PokemonInfo (
            val data: Card
        )