package br.com.fiap.feedbackroom.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment

class FormAdvogadoFragment: Fragment() {

        lateinit var binding: FragmentFormAdvogadosBinding

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            binding = FragmentFormAdvogadosBinding.inflate(inflater, container, false)
            val view = binding.root
            val appDb = AppDatabase.getDatabase(view.context)

            binding.buttonSalvar.setOnClickListener{
                val nome = binding.editTextNome.text.toString()
                val numeroEUfOab = binding.editTextnumeroEUFOab.text.toString()
                val seccionalOab = binding.editTextseccionalOAB.text.toString()
                val email = binding.editTextEmail.text.toString()
                val telefone = binding.editTextTelefone.text.toString()
                val novoAdvogado = Advogado(0, nome, numeroEUfOab, seccionalOab, email, telefone)
                appDb.advogadoDao().insert(novoAdvogado)



                Toast.makeText(view.context, "Registro Cadastrado com Sucesso!", Toast.LENGTH_LONG).show()

                binding.editTextNome.setText("")
                binding.editTextnumeroEUFOab.setText("")
                binding.editTextseccionalOAB.setText("")
                binding.editTextEmail.setText("")
                binding.editTextTelefone.setText("")


            }

            return view
        }
    }
}