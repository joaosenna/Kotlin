package br.com.fiap.feedbackroom.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull



@Entity(tableName = "advogados")

data class Advogado(
    @PrimaryKey(autoGenerate = true) var id: Int,
    @NotNull @ColumnInfo(name = "nome") var nome: String,
    var numeroEUfOab: String,
    var seccionalOab: String,
    var email: String,
    var telefone: Int,
)