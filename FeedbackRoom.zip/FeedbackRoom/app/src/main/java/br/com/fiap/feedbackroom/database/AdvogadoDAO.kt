package br.com.fiap.feedbackroom.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AdvogadoDAO{

    @Query("SELECT * FROM advogados ORDER BY nome ASC")

    fun getAll():List<Advogado>

    @Insert
    fun insert(vararg advogado: Advogado)
}