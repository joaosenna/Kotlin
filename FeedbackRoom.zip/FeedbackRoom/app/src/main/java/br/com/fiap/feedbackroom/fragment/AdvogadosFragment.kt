package br.com.fiap.feedbackroom.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.fiap.feedbackroom.database.AppDatabase


class AdvogadosFragment : Fragment() {


        lateinit var binding: FragmentAdvogadosBinding

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            binding = FragmentAdvogadosBinding.inflate(inflater, container, false)
            val view = binding.root

            val recyclerView = binding.recyclerView
            val appDb = AppDatabase.getDatabase(view.context)
            val alunos = appDb.alunoDao().getAll()

            recyclerView.layoutManager = LinearLayoutManager(view.context)
            recyclerView.adapter = AdvogadoAdapter(advogados)

            val itemDecor = DividerItemDecoration(view.context, DividerItemDecoration.VERTICAL)
            recyclerView.addItemDecoration(itemDecor)

            return view
        }

}