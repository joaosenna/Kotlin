package br.com.fiap.teammaiascaniaproject
'
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import br.com.fiap.teammaiascaniaproject.database.Caminhao

class CaminhaoAdapter (private val dataSet: List<Caminhao>): RecyclerView.Adapter<CaminhaoAdapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val textViewAluno: TextView
        val textViewCurso: TextView
        val textViewTurma: TextView
        val textViewAno: TextView
        val textViewValor: TextView

        init {
            textViewAluno = view.findViewById(R.id.textViewAluno)
            textViewCurso = view.findViewById(R.id.textViewCurso)
            textViewTurma = view.findViewById(R.id.textViewTurma)
            textViewAno = view.findViewById(R.id.textViewAno)
            textViewValor = view.findViewById(R.id.textViewValor)

        }
    }

    //Define o layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                        .inflate(R.layout.recyclerview_caminhao, parent, false)

        return ViewHolder(view)
    }

    //De/Para Objeto para o layout
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val aluno = dataSet[position]
        holder.textViewAluno.text = aluno.modelo
        holder.textViewCurso.text = aluno.valor
        holder.textViewTurma.text = aluno.cor
        holder.textViewAno.text = aluno.ano
        holder.textViewValor.text = aluno.placa

        holder.itemView.setOnClickListener {
            val bundle = bundleOf("aluno_id" to aluno.id)
            it.findNavController().navigate(R.id.action_caminhaoFragment_to_formCaminhaoFragment, bundle)
        }
    }

    //Retorna o tamanho da lista
    override fun getItemCount(): Int {
        return dataSet.size
    }
}'