package br.com.fiap.teammaiascaniaproject.database

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "caminhao")
data class Caminhao(@PrimaryKey(autoGenerate = true) var id: Int = 0,
                    @NonNull @ColumnInfo(name = "modelo") val modelo: String,
                    @NonNull @ColumnInfo(name = "placa")val placa: String,
                    @NonNull @ColumnInfo(name = "valor")val valor: String,
                    @NonNull @ColumnInfo(name = "ano")val ano: String,
                    @NonNull @ColumnInfo(name = "cor")val cor: String)