package br.com.fiap.teammaiascaniaproject.database

import androidx.room.*

@Dao
interface CaminhaoDao {
    @Query("SELECT * FROM caminhao ORDER BY modelo ASC")
    fun getAll(): List<Caminhao>;

    @Insert
    fun insert(vararg caminhao: Caminhao)

    @Query("SELECT * FROM caminhao WHERE id = :id")
    fun getById(id:Int): Caminhao

    @Delete
    fun delete (caminhao: Caminhao)

    @Update
    fun update (caminhao: Caminhao)
}