package br.com.fiap.teammaiascaniaproject.fragment

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import br.com.fiap.teammaiascaniaproject.R
import br.com.fiap.teammaiascaniaproject.database.Caminhao
import br.com.fiap.teammaiascaniaproject.database.AppDatabase
import br.com.fiap.teammaiascaniaproject.databinding.FragmentFormCaminhaoBinding


class FormCaminhaoFragment : Fragment() {

    lateinit var binding: FragmentFormCaminhaoBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFormCaminhaoBinding.inflate(inflater, container, false)
        val view = binding.root
        val appDb = AppDatabase.getDatabase(view.context)
        var caminhaoId = 0

        val bundle = this.arguments
        if (bundle != null) {
            caminhaoId = bundle.getInt("aluno_id", 0)
        }

        if (caminhaoId > 0){
            binding.buttonExcluir.visibility = View.VISIBLE
            binding.buttonAtualizar.visibility = View.VISIBLE
            binding.buttonSalvar.visibility = View.VISIBLE
            val caminhao = appDb.caminhaoDao().getById(caminhaoId)
            loadForm(caminhao)
        }


        binding.buttonSalvar.setOnClickListener {
            if(validarCamposObrigatorios(view)){
                Toast.makeText(view.context, R.string.registro_cadastrado_com_sucesso, Toast.LENGTH_LONG).show()
                val novoModelo = getFormCaminhao(0)
                appDb.caminhaoDao().insert(novoModelo)
                clearForm()


            }
        }

        binding.buttonExcluir.setOnClickListener{
            val builder = AlertDialog.Builder(view.context)
            builder.setMessage("Tem certeza que deseja excluir?")
                .setCancelable(false)
                .setPositiveButton("Sim"){ dialog, id ->
                    val caminhao = Caminhao(caminhaoId, "", "", "", "", "")
                    appDb.caminhaoDao().delete(caminhao)
                    clearForm()
                    it.findNavController().navigate(R.id.caminhaoFragment)
                }
                .setNegativeButton("Não") { dialog, id ->
                    dialog.dismiss()
                }
            val alert = builder.create()
            alert.show()
        }

        binding.buttonAtualizar.setOnClickListener {
            if (validarCamposObrigatorios(view)){
                Toast.makeText(view.context, "Registro atualizado com sucesso!", Toast.LENGTH_LONG).show()
                val caminhao = getFormCaminhao(caminhaoId)
                appDb.caminhaoDao().update(caminhao)
                clearForm()
                it.findNavController().navigate(R.id.action_formCaminhaoFragment_to_caminhaoFragment)
            }
        }

        return view
    }

    private fun getFormCaminhao(id: Int): Caminhao {
        val modelo = binding.editTextModelo.text.toString()
        val placa = binding.editTextPlaca.text.toString()
        val valor = binding.editTextValor.text.toString()
        val ano = binding.editTextAno.text.toString()
        val cor = binding.editTextCor.text.toString()
        val novoModelo = Caminhao(id, modelo, placa, valor, ano, cor)
        return novoModelo
    }

    private fun clearForm() {
        //Limpa o formulário
        binding.editTextModelo.setText(R.string.vazio)
        binding.editTextPlaca.setText(R.string.vazio)
        binding.editTextValor.setText(R.string.vazio)
        binding.editTextAno.setText(R.string.vazio)
        binding.editTextCor.setText(R.string.vazio)
    }

    private fun loadForm(caminhao: Caminhao) {
        binding.editTextModelo.setText(caminhao.modelo)
        binding.editTextPlaca.setText(caminhao.placa)
        binding.editTextValor.setText(caminhao.valor)
        binding.editTextAno.setText(caminhao.ano)
        binding.editTextCor.setText(caminhao.cor)
    }

    fun validarCamposObrigatorios(view: ConstraintLayout): Boolean{
        if(binding.editTextModelo.text.isNullOrEmpty()) {
            Toast.makeText(view.context, R.string.campo_modelo_e_obrigatorio, Toast.LENGTH_LONG)
                .show()
            binding.editTextModelo.requestFocus()
            return false
        }
        return true
    }
}