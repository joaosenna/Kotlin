package br.com.fiap.teammaiascaniaproject.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import br.com.fiap.teammaiascaniaproject.databinding.ActivityMainBinding
import br.com.fiap.teammaiascaniaproject.databinding.FragmentSobreBinding

class SobreFragment : Fragment () {

    lateinit var binding: FragmentSobreBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSobreBinding.inflate(inflater, container, false)
        val view = binding.root

        return view
    }
}