package br.com.fiap.androidndalunos.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AlunoDAO {

    @Query("SELECT * FROM alunos ORDER BY nome ASC")
    fun getAll() : List<Aluno>

    @Insert
    fun insert(vararg aluno: Aluno)
}