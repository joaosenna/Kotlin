package br.com.fiap.androidndalunos.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull

@Entity(tableName = "alunos")
data class Aluno(
                @PrimaryKey(autoGenerate = true) var id: Int,
                @NotNull @ColumnInfo(name = "nome") var nome: String,
                var rm:String, //sem o @ColumnInfo o banco usa o nome da variavel como padrão
                var curso:String,
                var ano:String,
                var turma: String
    )


