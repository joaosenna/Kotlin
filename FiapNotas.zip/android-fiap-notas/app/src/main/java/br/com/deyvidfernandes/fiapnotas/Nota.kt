package br.com.deyvidfernandes.fiapnotas

data class Nota(val disciplina: String,
                val nota: Double)
