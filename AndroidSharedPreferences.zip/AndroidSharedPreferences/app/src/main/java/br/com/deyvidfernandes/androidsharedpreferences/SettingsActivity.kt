package br.com.deyvidfernandes.androidsharedpreferences

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import br.com.deyvidfernandes.androidsharedpreferences.databinding.ActivityMainBinding
import br.com.deyvidfernandes.androidsharedpreferences.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    lateinit var shared: SharedPreferences
    val SHARED_PREFERENCES_NAME = "ALUNO"
    val SHARED_PREFERENCES_APELIDO = "apelido"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

       shared = getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)

        var apelido = shared.getString(SHARED_PREFERENCES_APELIDO, "")
        binding.editTextApelido.setText(apelido)

        binding.buttonSalvar.setOnClickListener{
            val edit = shared.edit()
            edit.putString(SHARED_PREFERENCES_APELIDO, binding.editTextApelido.text.toString())
            edit.apply()
            Toast.makeText(this, R.string.configuracoes_atualizadas_com_sucesso, Toast.LENGTH_LONG)
            finish()
        }
    }
}