package br.com.fiap.emaildemo

data class Email(val image:Int, val user:String, val title:String, val date:String, val favorite: Boolean )
