package br.com.fiap.emaildemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EmailAdapter (private val dataSet: List<Email>): RecyclerView.Adapter<EmailAdapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        //TODO: Criar as referências dos componentes do layout row

        val imageViewPerfil: ImageView
        val textViewUser: TextView
        val textViewDate: TextView
        val textViewTitle: TextView
        val imageButtonFavorite: ImageButton

        init {
            imageViewPerfil = view.findViewById(R.id.imageViewPerfil)
            textViewUser = view.findViewById(R.id.textViewUser)
            textViewDate = view.findViewById(R.id.textViewDate)
            textViewTitle = view.findViewById(R.id.textViewTitle)
            imageButtonFavorite = view.findViewById(R.id.imageButtonFavorite)
            
        }

  }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        //TODO: Definir o layout

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycleview_email,parent,false)
        retun ViewHolder(view)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        //TODO: Recuperar os itens do objeto lista e montar o DE/PARA
        val email = dataSet[position]

        holder.imageViewPerfil.setImageResource(email.image)
        holder.textViewUser.text = email.user
        holder.textViewTitle.text = email.title
        holder.textViewDate.text = email.date

        if(email.favorite){
            holder.imageButtonFavorite.setImageResource(R.drawable.ic_star_on)
        }
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }
}